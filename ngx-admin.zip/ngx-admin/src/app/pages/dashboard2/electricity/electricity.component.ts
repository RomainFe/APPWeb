import { Component, OnDestroy } from '@angular/core';
import { NbThemeService } from '@nebular/theme';
import { HttpClient } from '@angular/common/http';
import { Electricity,Month, ElectricityChart, ElectricityData } from '../../../@core/data/electricity';
import { takeWhile } from 'rxjs/operators';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'ngx-electricity',
  styleUrls: ['./electricity.component.scss'],
  templateUrl: './electricity.component.html',
})
export class ElectricityComponent implements OnDestroy {

  private alive = true;

  listData: Electricity[];
  chartData = [{}] as ElectricityChart[];
   chartPoints = [];
  private chart_index_value = 0;
  type = 'Jour';
  types = ['Jour', 'Mois', 'Année'];

  currentTheme: string;
  themeSubscription: any;

  constructor(private electricityService: ElectricityData,
              private themeService: NbThemeService,
              private http: HttpClient) {
    this.themeService.getJsTheme()
      .pipe(takeWhile(() => this.alive))
      .subscribe(theme => {
        this.currentTheme = theme.name;
    });

    forkJoin(
      this.electricityService.getListData(),
      this.electricityService.getChartData(),
    )
      .pipe(takeWhile(() => this.alive))
      .subscribe(([listData, chartData]: [Electricity[], ElectricityChart[]] ) => {
        this.listData = listData;
        this.chartData = chartData;
      });
      this.updateData();
  }

  updateData(){
    this.http.get("http://192.168.0.40/devicestate?token=e4bd9794ab690ae94f8125e6435335f53ffd1223&devicetype=5&skip=20")  // Récupération des valeurs d'Enedis sur l'API Gladys
    .subscribe(data => {                                                                                                  // Promise : récupérer le resultat "data"
      var last_day = '';
      var last_month = '';
      var month_index_data=-1;
      var day_index_data=-1;
      var i = 0;

      console.log(data);
      for(i=0;i<(Object.keys(data).length);i++){                                                                          // Boucle parcourant toutes les valeurs retourné par Gladys
        if(data[i].dateFormat.split(' ')[1] != last_month){                                                               // SI data[i] correpond a un nouveau mois, on créé un nouveau mois
          month_index_data++;
          last_month = data[i].dateFormat.split(' ')[1] ;                                                                 // Récupérer le mois de la valeur
          var month = {} as Electricity;
          this.listData[month_index_data] = Object.assign(month, {                                                        // Création du nouveau mois
            title: last_month,
            active: true,
            months: [{}] as Month[]
          });
          console.log(this.listData);

      }
      if( data[i].dateFormat.split(' ')[0] != last_day){                                                                  // SI data[i] correpond a un nouveau jour, on créé un nouveau jour
        if(day_index_data == -1){
          this.chartData[this.chart_index_value++] = {                                                                    // Permet une optimisation de l'affichage sur le graphique
            value :data[i].value,
            label :""
          };
        }
        last_day = data[i].dateFormat.split(' ')[0];
        day_index_data++;
        var day = {} as Month;
        this.chartData[this.chart_index_value] = {                                                                        // Récupérer le jour de la valeur
          value :data[i].value,
          label :last_day
        };
        this.chart_index_value++;
        this.listData[month_index_data].months[day_index_data] = Object.assign(day,{                                      // Création du nouveau jour
            month: last_day,
            delta: '',
            down: true,
            kWatts: data[i].value,
            cost: '',
          });
      }
      if(i == (Object.keys(data).length)-1){                                                                             // Permet une optimisation de l'affichage sur le graphique
        this.chartData[this.chart_index_value++] = {
          value :data[i].value,
          label :""
        };
      }
    }
  });
}

  ngOnDestroy() {
    this.alive = false;
  }
}
