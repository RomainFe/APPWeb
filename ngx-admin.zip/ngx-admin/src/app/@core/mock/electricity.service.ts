import { Injectable } from '@angular/core';
import { of as observableOf, Observable } from 'rxjs';
import { Electricity, Month, ElectricityChart, ElectricityData } from '../data/electricity';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ElectricityService extends ElectricityData {




  private listData= [{}] as Electricity[] ;
  private chart_index_value = 0;


 chartPoints = [];
  chartData: ElectricityChart[];

  constructor() {
    super();
    this.chartData = this.chartPoints.map((p, index) => ({
      label: (index % 5 === 3) ? `${Math.round(index / 5)}` : '',
      value: p
    }));
  }

  getListData(): Observable<Electricity[]> {

    return observableOf(this.listData);
  }

  getChartData(): Observable<ElectricityChart[]> {
    return observableOf(this.chartData);
  }



}
