var express = require('express'); //nous avons besoin du module express
global.request = require("request-promise");
var cors = require('cors');
global.sql = require('mssql');
var app = express();
var myRouter = express.Router();

var hostname = 'innovator'; //SERVER NAME
var port = 5500; // API PORT



//////////////////// ARAS PARAMETERS /////////////////////////////////////////////////////////////////////
var aras_base_URL = "http://innovator/ARAS11SP15Server/server/odata/";
var aras_token  = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IlhiYkpkMEpaTDhpdTdlOEg2eS1Vb2dNLXdzTSIsImtpZCI6IlhiYkpkMEpaTDhpdTdlOEg2eS1Vb2dNLXdzTSJ9.eyJpc3MiOiJPQXV0aFNlcnZlciIsImF1ZCI6Ik9BdXRoU2VydmVyL3Jlc291cmNlcyIsImV4cCI6MTU1ODU4MTI3NCwibmJmIjoxNTU4NTUyNDc0LCJjbGllbnRfaWQiOiJJT01BcHAiLCJzY29wZSI6Iklubm92YXRvciIsInN1YiI6ImFkbWluIiwiYXV0aF90aW1lIjoxNTU4NTUyNDc0LCJpZHAiOiJpZHNydiIsIm5hbWUiOiJhZG1pbiIsInVzZXJuYW1lIjoiYWRtaW4iLCJkYXRhYmFzZSI6IkFSQVMxMVNQMTVTZXJ2ZXIiLCJhbXIiOlsicGFzc3dvcmQiXX0.fagiyavYw71FHjua4Q5Vdf4abIKjrkXJNZdltw3MYxc6L2_7q4xt6iwWEk4W6nYZDOTfUIjeqlj2gvSkvVAT9u8MV1nn1kqJV_RbZBPxPhNrvDIENxl7WZdu6Cpv6N4zg4Zv8lKZOikH3Ve2jj2HRmvgE92VTXQGX_vj--sTWLX3yIngpL4atIYIOERWfwtc1vvz4S0GrNoWOB5raGVknGAGPEUelocR4RJGkjRhmMsf-hRDxQS7spF1E9ah0MGZFjUg1I9SSwqkZvmIqGjQJs8U6-RIG44aGjRCz8N9PApDrdzg-usaACrtGNYHMomHWpr1HqjVBGoGJTmjaABCmg";
var aras_db = "ARAS11SP15Server";
var aras_user = "admin";
var aras_password = "607920b64fe136f9ab2389e371852af2";   //MD5 hash
var aras_options =
{
	uri: aras_base_URL,
	headers: {'Authorization' : 'Bearer '+aras_token},
	json: true // Automatically parses the JSON string in the response
};
////////////////////////// SQL PROCESS SIMULATION DATABASE PARAMETERS ////////////////////////////////////////////////////////////
var sim_db_config = {
	user: 'sa',
	password: 'innovator',
	server: 'innovator',
	database: 'mppSimulationDB'
};

/////////////////////////////////////////////////////////////////////////////////////////////////
myRouter.route('/') // il faudra dans l'URI le parametre value
.get(function(req,res)
{
	aras_options.uri = aras_base_URL;
	aras_options.uri = aras_options.uri+"mpp_ProcessSimulation?$filter=simulation_master eq '"+req.query.master_id+
	"'&$select=id,simulation_number,simulation_master,simulation_parent,process_plan&$expand=simulation_master,simulation_parent,process_plan" ;
	this.request(aras_options)
	.then(function(simulations)
	{
		// connect to your database
		sql.connect(sim_db_config, function (err)
		{
			if (err) console.log(err);

			// create Request object
			var db = new sql.Request();
			//console.log(Object.keys(simulations.value).length);
			// query to the database and get the records
			for(var i=0;i<(Object.keys(simulations.value).length);i++){
				if(simulations.value[i].simulation_parent==null){
					simulations.value[i].simulation_parent ="";
					simulations.value[i].simulation_parent.id = "";
				}
				db.query("Insert into innovator.mpp_ProcessSimulation (id,simulation_number,process_plan,simulation_parent,simulation_master) values ('"+simulations.value[i].id+"','"+simulations.value[i].simulation_number+"','"+simulations.value[i].process_plan.id+"','"+simulations.value[i].simulation_parent.id+"','"+simulations.value[i].simulation_master.id+"')", function (err) { if (err) console.log(err) });

				aras_options.uri = aras_base_URL;
				aras_options.uri = aras_options.uri+"mpp_ProcessPlan?$filter=id eq '"+simulations.value[i].process_plan.id+
				"'&$select=id,location,name,item_number" ;
				this.request(aras_options)
				.then(function(process_plan)
				{
					if (err) console.log(err);
					var db = new sql.Request();
					for(var u=0;u<(Object.keys(process_plan.value).length);u++){
						db.query("Insert into innovator.mpp_ProcessPlan (id,location,name,item_number) values ('"+process_plan.value[u].id+"','"+process_plan.value[u].location+"','"+process_plan.value[u].name+"','"+process_plan.value[u].item_number+"')", function (err) { if (err) console.log(err) });
					}
				});

				aras_options.uri = aras_base_URL;
				aras_options.uri = aras_options.uri+"mpp_Operation?$filter=source_id eq '"+simulations.value[i].process_plan.id+
				"'&$select=id,source_id,sort_order,cycle_time,setup_time,related_id&$expand=source_id" ;
				this.request(aras_options)
				.then(function(operations)
				{
					if (err) console.log(err);
					var db = new sql.Request();
					for(var j=0;j<(Object.keys(operations.value).length);j++){
						if(operations.value[j].cycle_time==null){operations.value[j].cycle_time=0;}
						if(operations.value[j].setup_time==null){operations.value[j].setup_time=0;}
						db.query("Insert into innovator.mpp_Operation (id,source_id,sort_order,cycle_time,setup_time) values ('"+operations.value[j].id+"','"+operations.value[j].source_id.id+"',"+operations.value[j].sort_order+","+operations.value[j].cycle_time+","+operations.value[j].setup_time+")", function (err) { if (err) console.log(err) });
						aras_options.uri = aras_base_URL;
						aras_options.uri = aras_options.uri+"mpp_OperationConsumedPart?$filter=source_id eq '"+operations.value[j].id+
						"'&$select=id,source_id,sort_order,quantity,related_id&$expand=source_id,related_id" ;
						//console.log(aras_options.uri);
						this.request(aras_options)
						.then(function(operations_c_part)
						{
							for(var k=0;k<(Object.keys(operations_c_part.value).length);k++){
								db.query("Insert into innovator.mpp_OperationConsumedPart (id,source_id,sort_order,quantity,related_id) values ('"+operations_c_part.value[k].id+"','"+operations_c_part.value[k].source_id.id+"',"+operations_c_part.value[k].sort_order+","+operations_c_part.value[k].quantity+",'"+operations_c_part.value[k].related_id.id+"')", function (err) { if (err) console.log(err) });
							}
						});
					}
				});

				aras_options.uri = aras_base_URL;
				aras_options.uri = aras_options.uri+"mpp_SimulationChild?$filter=source_id eq '"+simulations.value[i].id+
				"'&$select=id,source_id,related_id&$expand=source_id,related_id" ;
				this.request(aras_options)
				.then(function(simulations_child)
				{
					if (err) console.log(err);
					var db = new sql.Request();
					for(var u=0;u<(Object.keys(simulations_child.value).length);u++){
						db.query("Insert into innovator.mpp_SimulationChild (id,source_id,related_id) values ('"+simulations_child.value[u].id+"','"+simulations_child.value[u].source_id.id+"','"+simulations_child.value[u].related_id.id+"')", function (err) { if (err) console.log(err) });
					}
				});

				aras_options.uri = aras_base_URL;
				aras_options.uri = aras_options.uri+"mpp_SimulationConsumedPart?$filter=source_id eq '"+simulations.value[i].id+
				"'&$select=id,source_id,operation,variable_target,variable_value,variable_name&$expand=source_id,operation,variable_target" ;
				this.request(aras_options)
				.then(function(simulations_c_part)
				{
					if (err) console.log(err);
					var db = new sql.Request();
					for(var u=0;u<(Object.keys(simulations_c_part.value).length);u++){
						db.query("Insert into innovator.mpp_SimulationConsumedPart (id,source_id,operation,variable_target,variable_value,variable_name) values ('"+simulations_c_part.value[u].id+"','"+simulations_c_part.value[u].source_id.id+"','"+simulations_c_part.value[u].operation.id+"','"+simulations_c_part.value[u].variable_target.id+"',"+simulations_c_part.value[u].variable_value+",'"+simulations_c_part.value[u].variable_name+"')", function (err) { if (err) console.log(err) });
					}
				});

				aras_options.uri = aras_base_URL;
				aras_options.uri = aras_options.uri+"mpp_SimulationProducedPart?$filter=source_id eq '"+simulations.value[i].id+
				"'&$select=id,source_id,related_id&$expand=source_id,related_id" ;
				this.request(aras_options)
				.then(function(simulations_p_part)
				{
					if (err) console.log(err);
					var db = new sql.Request();
					for(var u=0;u<(Object.keys(simulations_p_part.value).length);u++){
						db.query("Insert into innovator.mpp_SimulationProducedPart (id,source_id,related_id) values ('"+simulations_p_part.value[u].id+"','"+simulations_p_part.value[u].source_id.id+"','"+simulations_p_part.value[u].related_id.id+"')", function (err) { if (err) console.log(err) });
					}
				});
			}
		})
		res.jsonp(simulations);
	});

})

app.use(cors());
app.use(myRouter); // On applique les routes sur notre API
app.options("/*", function(req, res, next){
	res.header('Access-Control-Allow-Origin', '*');
	res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
	res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
	res.send(200);
});

// Démarrer le serveur
app.listen(port, hostname, function(){
	console.log("Mon serveur fonctionne sur http://"+ hostname +":"+port+"\n");
});




function insertRow() {
	//2.
	var dbConn = new sql.Connection(config);
	//3.
	dbConn.connect().then(function () {
		//4.
		var transaction = new sql.Transaction(dbConn);
		//5.
		transaction.begin().then(function () {
			//6.
			var request = new sql.Request(transaction);
			//7.
			request.query("Insert into innovator.mpp_ProcessSimulation (id,simulation_number,process_plan,simulation_parent,simulation_master) values ('"+simulations.value[0].id+"','"+simulations.value[0].simulation_number+"','"+simulations.value[0].process_plan.id+"','"+simulations.value[0].simulation_parent.id+"','"+simulations.value[0].simulation_master.id+"')")
			.then(function () {
				//8.
				transaction.commit().then(function (recordSet) {
					console.log(recordSet);
					dbConn.close();
				}).catch(function (err) {
					//9.
					console.log("Error in Transaction Commit " + err);
					dbConn.close();
				});
			}).catch(function (err) {
				//10.
				console.log("Error in Transaction Begin " + err);
				dbConn.close();
			});

		}).catch(function (err) {
			//11.
			console.log(err);
			dbConn.close();
		});
	}).catch(function (err) {
		//12.
		console.log(err);
	});
}
//13.
